import React from "react";
import Input from "./Input";
import Select from "./Select";

const Form = (props) => {
  const countries = [
    { label: "India", value: "India" },
    { label: "USA", value: "USA" },
    { label: "Canada", value: "Canada" },
  ];

  const citiesByCountry = {
    India: [
      { label: "Mumbai", value: "Mumbai" },
      { label: "Delhi", value: "Delhi" },
      { label: "Pune", value: "Pune" },
    ],
    USA: [
      { label: "New York", value: "New York" },
      { label: "Los Angeles", value: "Los Angeles" },
      { label: "Chicago", value: "Chicago" },
    ],
    Canada: [
      { label: "Toronto", value: "Toronto" },
      { label: "Vancouver", value: "Vancouver" },
      { label: "Montreal", value: "Montreal" },
    ],
  };

  return (
    <div
      style={{
        maxWidth: "600px",
        margin: "30px auto",
        padding: "20px",
        border: "1px solid #eee",
        borderRadius: "8px",
        boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
      }}
    >
      <h2>Registration Form</h2>
      <form onSubmit={props.handleSubmit}>
        <Input
          label="First Name"
          type="text"
          name="firstName"
          value={props.formData.firstName}
          onChange={props.handleChange}
          onBlur={props.handleBlur}
          error={props.touched.firstName && props.errors.firstName}
        />
        <Input
          label="Last Name"
          type="text"
          name="lastName"
          value={props.formData.lastName}
          onChange={props.handleChange}
          onBlur={props.handleBlur}
          error={props.touched.lastName && props.errors.lastName}
        />
        <Input
          label="Username"
          type="text"
          name="username"
          value={props.formData.username}
          onChange={props.handleChange}
          onBlur={props.handleBlur}
          error={props.touched.username && props.errors.username}
        />
        <Input
          label="E-mail"
          type="email"
          name="email"
          value={props.formData.email}
          onChange={props.handleChange}
          onBlur={props.handleBlur}
          error={props.touched.email && props.errors.email}
        />
        <div style={{ marginBottom: "15px" }}>
          <Input
            label="Password"
            type={props.formData.showPassword ? "text" : "password"}
            name="password"
            value={props.formData.password}
            onChange={props.handleChange}
            onBlur={props.handleBlur}
            error={props.touched.password && props.errors.password}
          />
          <label
            style={{ display: "flex", alignItems: "center", fontSize: "0.9em" }}
          >
            <input
              type="checkbox"
              name="showPassword"
              checked={props.formData.showPassword}
              onChange={props.togglePasswordVisibility}
              style={{ marginRight: "5px" }}
            />
            Show Password
          </label>
        </div>
        <div style={{ display: "flex", gap: "10px", marginBottom: "15px" }}>
          <div style={{ flex: 0.3 }}>
            <Input
              label="Country Code"
              type="text"
              name="phoneCountryCode"
              value={props.formData.phoneCountryCode}
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              error={
                props.touched.phoneCountryCode && props.errors.phoneCountryCode
              }
              textAlign="center"
            />
          </div>
          <div style={{ flex: 0.7 }}>
            <Input
              label="Phone Number"
              type="text"
              name="phoneNumber"
              value={props.formData.phoneNumber}
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              error={props.touched.phoneNumber && props.errors.phoneNumber}
            />
          </div>
        </div>
        <Select
          label="Country"
          name="country"
          value={props.formData.country}
          onChange={props.handleChange}
          onBlur={props.handleBlur}
          options={countries}
          error={props.touched.country && props.errors.country}
        />

        {props.formData.country && (
          <Select
            label="City"
            name="city"
            value={props.formData.city}
            onChange={props.handleChange}
            onBlur={props.handleBlur}
            options={citiesByCountry[props.formData.country] || []}
            error={props.touched.city && props.errors.city}
          />
        )}
        <Input
          label="PAN No."
          type="text"
          name="panNo"
          value={props.formData.panNo}
          onChange={props.handleChange}
          onBlur={props.handleBlur}
          error={props.touched.panNo && props.errors.panNo}
        />
        <Input
          label="Aadhar No."
          type="text"
          name="aadharNo"
          value={props.formData.aadharNo}
          onChange={props.handleChange}
          onBlur={props.handleBlur}
          error={props.touched.aadharNo && props.errors.aadharNo}
        />
        <button
          type="submit"
          disabled={!props.isFormValid}
          style={{
            padding: "10px 20px",
            backgroundColor: props.isFormValid ? "#007bff" : "#cccccc",
            color: "white",
            border: "none",
            borderRadius: "4px",
            cursor: props.isFormValid ? "pointer" : "not-allowed",
            fontSize: "1em",
          }}
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default Form;
