import React from "react";

const SubmittedDetails = (props) => {
  if (!props.data || Object.keys(props.data).length === 0) {
    return (
      <div
        style={{
          maxWidth: "600px",
          margin: "30px auto",
          padding: "20px",
          border: "1px solid #eee",
          borderRadius: "8px",
          boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
        }}
      >
        <h3>No details submitted yet.</h3>
        <p>Please fill out the form to see the details here.</p>
      </div>
    );
  }

  return (
    <div
      style={{
        maxWidth: "600px",
        margin: "30px auto",
        padding: "20px",
        border: "1px solid #eee",
        borderRadius: "8px",
        boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
      }}
    >
      <h2>Submitted Details</h2>
      {/* Iterate over the key-value pairs of the submitted data object */}
      {Object.entries(props.data).map(
        ([key, value]) =>
          // Skip displaying the internal 'showPassword' flag
          key !== "showPassword" && (
            <p key={key} style={{ marginBottom: "8px" }}>
              <strong style={{ textTransform: "capitalize" }}>
                {/* Format key names for better display (e.g., 'firstName' -> 'First Name') */}
                {key
                  .replace(/([A-Z])/g, " $1")
                  .replace(/^./, (str) => str.toUpperCase())}
                :
              </strong>{" "}
              {String(value)}{" "}
              {/* Ensure value is converted to string for display */}
            </p>
          )
      )}
      <button
        onClick={props.onGoBack} // Call the function passed from App.js to return to the form
        style={{
          padding: "10px 20px",
          backgroundColor: "#6c757d",
          color: "white",
          border: "none",
          borderRadius: "4px",
          cursor: "pointer",
          fontSize: "1em",
          marginTop: "20px",
        }}
      >
        Go Back
      </button>
    </div>
  );
};

export default SubmittedDetails;
