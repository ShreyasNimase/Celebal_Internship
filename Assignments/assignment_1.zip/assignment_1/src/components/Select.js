import React from "react";

const Select = (props) => {
  return (
    <div style={{ marginBottom: "15px" }}>
      <label
        htmlFor={props.name}
        style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}
      >
        {props.label}:
      </label>
      <select
        id={props.name}
        name={props.name}
        value={props.value}
        onChange={props.onChange}
        onBlur={props.onBlur}
        style={{
          width: "100%",
          padding: "8px",
          border: "1px solid #ccc",
          borderRadius: "4px",
          boxSizing: "border-box",
          borderColor: props.error ? "red" : "#ccc",
        }}
      >
        <option value="">-- Please Select --</option>{" "}
        {props.options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {props.error && (
        <p style={{ color: "red", fontSize: "0.8em", marginTop: "5px" }}>
          {props.error}
        </p>
      )}
    </div>
  );
};

export default Select;
