import React from "react";
import Form from "./components/Form";
import SubmittedDetails from "./components/SubmittedDetails";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      formData: {
        firstName: "",
        lastName: "",
        username: "",
        email: "",
        password: "",
        showPassword: false,
        phoneCountryCode: "+91",
        phoneNumber: "",
        country: "",
        city: "",
        panNo: "",
        aadharNo: "",
      },
      errors: {},
      touched: {},
      submittedData: null,
      currentRoute: "form",
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleBlur = this.handleBlur.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.validate = this.validate.bind(this);
    this.togglePasswordVisibility = this.togglePasswordVisibility.bind(this);
    this.handleGoBack = this.handleGoBack.bind(this);
  }

  //validation logic
  validate(formData) {
    const newErrors = {};

    // 1. Required Field Checks
    if (!formData.firstName.trim())
      newErrors.firstName = "First Name is required.";
    if (!formData.lastName.trim())
      newErrors.lastName = "Last Name is required.";
    if (!formData.username.trim()) newErrors.username = "Username is required.";
    if (!formData.email.trim()) newErrors.email = "E-mail is required.";
    if (!formData.password.trim()) newErrors.password = "Password is required.";
    if (!formData.phoneNumber.trim())
      newErrors.phoneNumber = "Phone Number is required.";
    if (!formData.country) newErrors.country = "Country is required.";
    if (!formData.city) newErrors.city = "City is required.";
    if (!formData.panNo.trim()) newErrors.panNo = "PAN No. is required.";
    if (!formData.aadharNo.trim())
      newErrors.aadharNo = "Aadhar No. is required.";

    // 2. Format Validations
    // Email format (basic regex)
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Invalid E-mail format.";
    }

    // Password strength (at least 6 characters)
    if (formData.password && formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters long.";
    }

    // Phone number format (10 digits, numbers only)
    if (formData.phoneNumber && !/^\d{10}$/.test(formData.phoneNumber)) {
      newErrors.phoneNumber = "Phone number must be 10 digits.";
    }

    // PAN No. format (e.g., ABCDE1234F - 5 letters, 4 numbers, 1 letter)
    if (
      formData.panNo &&
      !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(formData.panNo.toUpperCase())
    ) {
      newErrors.panNo = "Invalid PAN No. format (e.g., ABCDE1234F).";
    }

    // Aadhar No. format (12 digits)
    if (formData.aadharNo && !/^\d{12}$/.test(formData.aadharNo)) {
      newErrors.aadharNo = "Aadhar No. must be 12 digits.";
    }

    return newErrors;
  }

  // Event handler for input changes (typing).
  handleChange(e) {
    const { name, value, type, checked } = e.target;
    this.setState((prevState) => {
      const updatedFormData = {
        ...prevState.formData,
        [name]: type === "checkbox" ? checked : value,
      };

      // Recalculate errors immediately with the new formData.
      const updatedErrors = this.validate(updatedFormData);

      return {
        formData: updatedFormData,
        errors: updatedErrors,
      };
    });
  }

  // Event handler for when an input field loses focus (user clicks away).
  handleBlur(e) {
    const { name } = e.target;

    this.setState((prevState) => ({
      touched: {
        ...prevState.touched,
        [name]: true,
      },

      errors: this.validate(prevState.formData),
    }));
  }

  togglePasswordVisibility() {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        showPassword: !prevState.formData.showPassword,
      },
    }));
  }

  handleSubmit(e) {
    e.preventDefault();

    const allTouched = Object.keys(this.state.formData).reduce(
      (acc, key) => ({ ...acc, [key]: true }),
      {}
    );
    this.setState({ touched: allTouched });

    const currentErrors = this.validate(this.state.formData);
    this.setState({ errors: currentErrors });

    const isValid = Object.keys(currentErrors).length === 0;

    if (isValid) {
      this.setState({
        submittedData: this.state.formData,
        currentRoute: "details",
      });
      console.log("Form submitted successfully:", this.state.formData);
    } else {
      console.log("Form has errors. Please correct them.");
    }
  }

  handleGoBack() {
    this.setState({
      currentRoute: "form",
      submittedData: null,

      formData: {
        firstName: "",
        lastName: "",
        username: "",
        email: "",
        password: "",
        showPassword: false,
        phoneCountryCode: "+91",
        phoneNumber: "",
        country: "",
        city: "",
        panNo: "",
        aadharNo: "",
      },
      errors: {},
      touched: {},
    });
  }

  render() {
    const { formData, errors, touched, submittedData, currentRoute } =
      this.state;

    const isFormValid = Object.keys(this.validate(formData)).length === 0;

    return (
      <div>
        {currentRoute === "form" ? (
          <Form
            formData={formData}
            errors={errors}
            touched={touched}
            handleChange={this.handleChange}
            handleBlur={this.handleBlur}
            handleSubmit={this.handleSubmit}
            togglePasswordVisibility={this.togglePasswordVisibility}
            isFormValid={isFormValid}
          />
        ) : (
          <SubmittedDetails data={submittedData} onGoBack={this.handleGoBack} />
        )}
      </div>
    );
  }
}

export default App;
